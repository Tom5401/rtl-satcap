Shapefiles from https://www.naturalearthdata.com

countries: https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-admin-0-countries/
states: https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-admin-1-states-provinces/
lakes: https://www.naturalearthdata.com/downloads/10m-physical-vectors/10m-lakes/
